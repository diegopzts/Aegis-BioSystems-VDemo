import * as THREE from 'three';
import { OrbitControls } from 'three/addons/controls/OrbitControls.js';

const visor = document.getElementById('visor');
const scene = new THREE.Scene();
const camera = new THREE.PerspectiveCamera(50, visor.clientWidth / visor.clientHeight, 0.1, 100);
camera.position.set(0, 1.5, 6);

const renderer = new THREE.WebGLRenderer({ antialias: true });
renderer.setSize(visor.clientWidth, visor.clientHeight);
visor.appendChild(renderer.domElement);

scene.add(new THREE.AmbientLight(0xffffff, 0.7));
const luz = new THREE.DirectionalLight(0xffffff, 1);
luz.position.set(3, 5, 5);
scene.add(luz);

const controles = new OrbitControls(camera, renderer.domElement);
controles.target.set(0, 1, 0);

const datos = {
  cabeza:  { nombre: 'Cerebro / Estrés',   valor: 'HRV 45 ms',         estado: 'amarillo', tip: 'Haz 5 minutos de respiración guiada.' },
  torso:   { nombre: 'Corazón',            valor: '72 lpm',            estado: 'verde',    tip: 'Mantén tu rutina de ejercicio.' },
  piernas: { nombre: 'Huesos y músculos',  valor: 'Ejercicio 20 min',  estado: 'rojo',     tip: 'Completa tu sesión en la cinta.' }
};
const colores = { verde: 0x2ecc71, amarillo: 0xf1c40f, rojo: 0xe74c3c };

function parte(geo, y, clave) {
  const m = new THREE.Mesh(geo, new THREE.MeshStandardMaterial({ color: colores[datos[clave].estado] }));
  m.position.y = y;
  m.userData.clave = clave;
  scene.add(m);
  return m;
}

const partes = [
  parte(new THREE.SphereGeometry(0.5, 32, 32), 2.6, 'cabeza'),
  parte(new THREE.CylinderGeometry(0.6, 0.5, 1.6, 32), 1.3, 'torso'),
  parte(new THREE.CylinderGeometry(0.35, 0.3, 1.8, 32), -0.4, 'piernas')
];

const ray = new THREE.Raycaster();
const mouse = new THREE.Vector2();
renderer.domElement.addEventListener('click', e => {
  const r = renderer.domElement.getBoundingClientRect();
  mouse.x = ((e.clientX - r.left) / r.width) * 2 - 1;
  mouse.y = -((e.clientY - r.top) / r.height) * 2 + 1;
  ray.setFromCamera(mouse, camera);
  const hit = ray.intersectObjects(partes)[0];
  if (hit) {
    const d = datos[hit.object.userData.clave];
    document.getElementById('info').innerHTML =
      `<b>${d.nombre}</b><br>Valor: ${d.valor}<br>Estado: ${d.estado}<br><br>💡 ${d.tip}`;
  }
});

(function animar() {
  requestAnimationFrame(animar);
  controles.update();
  renderer.render(scene, camera);
})();